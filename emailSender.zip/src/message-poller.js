const AWS = require('aws-sdk');
const helper = require('./message-poller-helper.js');

const nodemailer = require('nodemailer');
const sesTransport = require('nodemailer-ses-transport');

class messagePoller {
  constructor(event, context, callback) {
    this.event = event;
    this.context = context;
    this.callback = callback;
  }

  startProcess() {
    return new Promise(async (resolve, reject) => {
      try {
        console.log('Event received : ', this.event);
        let emailIDs = [];
        this.event.Records.forEach((record) => {
          emailIDs.push(record.body);
        });

        for (const emailID of emailIDs) {
          this.sendBulkEmail(emailID);
          // this.sendBulkMailSMTP(emailID);
        }

        var responseObj = helper.responseObj('Email sent successfully', 200);
        responseObj.data = {};
        resolve(responseObj);
      } catch (error) {
        console.log('Error SendBulkEmail StartProcess', error);
        var errorObject = {};
        errorObject.statusCode = 500;
        errorObject.statusMessage = JSON.stringify(error);
        reject(errorObject);
      }
    });
  }

  sendBulkEmail(emailID) {
    const mailOptions = {
      from: emailID,
      to: emailID,
      text: 'This is some text',
      html: '<b>This is some HTML</b>',
    };

    function callback(error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log('Message sent: ' + info.response);
      }
    }

    // Send e-mail using SMTP
    mailOptions.subject = 'Nodemailer SMTP transporter';
    const smtpTransporter = nodemailer.createTransport({
      port: 2587,
      host: '',
      secureConnection: false,
      auth: {
        user: '',
        pass: '',
      },
      tls: {
        ciphers: 'SSLv3',
      },
      debug: true,
    });
    smtpTransporter.sendMail(mailOptions, callback);
  }

  // get bad word list from bucket
  // sendBulkEmail(toEmailID) {
  //   return new Promise(async (resolve, reject) => {
  //     try {
  //       console.log('Inside sendBulkEmail');
  //       var ses = new AWS.SES();

  //       var params = {
  //         Destination: {
  //           ToAddresses: [toEmailID],
  //         },
  //         Message: {
  //           Body: {
  //             Html: {
  //               Charset: 'UTF-8',
  //               Data: 'This message body contains HTML formatting. It can, for example, contain links like this one: <a class="ulink" href="http://docs.aws.amazon.com/ses/latest/DeveloperGuide" target="_blank">Amazon SES Developer Guide</a>.',
  //             },
  //             Text: {
  //               Charset: 'UTF-8',
  //               Data: 'This is the message body in text format.',
  //             },
  //           },
  //           Subject: {
  //             Charset: 'UTF-8',
  //             Data: 'Test email',
  //           },
  //         },
  //         Source: 'pmrubenrao@gmail.com',
  //       };
  //       console.log('sendBulkEmail params : ', params);
  //       ses.sendEmail(params, function (err, data) {
  //         if (err) {
  //           console.log('Error in sendBulkEmail : ', JSON.stringify(err)); // an error occurred
  //           reject();
  //         } else {
  //           console.log('sendBulkEmail res : ', data);
  //           resolve(data);
  //         }
  //       });
  //     } catch (error) {
  //       console.log('error in sendBulkEmail : ', error);
  //       reject(error);
  //     }
  //   });
  // }
}

module.exports = messagePoller;
