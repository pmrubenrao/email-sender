/**
 *  v1.0: This lambda function would trigger through SNS notiifcation
 *  if ant message delivery failed. For example if the message bounce from the
 *  user mailserver(Bounce).
 */

const aws = require('aws-sdk');
aws.config.update({ region: 'us-east-1' });
const ddb = new aws.DynamoDB.DocumentClient();
const s3 = new AWS.S3({ apiVersion: '2006-03-01' });
const { v4: uuidv4 } = require('uuid');

exports.handler = async function (event, context) {
  const SnsPublishTime = event.Records[0].Sns.Timestamp;
  //   const SnsTopicArn = event.Records[0].Sns.TopicArn;
  let SESMessage = event.Records[0].Sns.Message;
  let messageLogger = '';

  SESMessage = JSON.parse(SESMessage);

  const SESMessageType = SESMessage.notificationType;
  const SESMessageId = SESMessage.mail.messageId;
  const SESDestinationAddress = SESMessage.mail.destination.toString();
  //   const LambdaReceiveTime = new Date().toString();

  console.log(
    'incoming event in from SNS',
    console.log(JSON.Stringify(event.Records[0].Sns))
  );

  /**
   *  Check database if the message delivery already failed for a particular user email address
   * If its failed then increase the retry counter by 1 and max upto 3. Once it reaches count of 3 user email
   * address would be excluded from re-push mechanisme.
   */

  let queriedEmail = '';
  let queriedMessageId = '';
  let queriedSnsPublishTime = '';

  const paramsInsert = {
    TableName: 'FailedEmailNotifications',
    Item: {
      FailedEmailMessageId: SESMessageId,
      SnsPublishTime: SnsPublishTime,
      SESDestinationAddress: SESDestinationAddress,
      retryCount: 0,
      SESMessageType: SESMessageType,
    },
  };

  /**
   * finding the already failed message message through scan() method.
   * Loop over the request doesnt make any sense because failed-lambda-handler
   * will run for each failed  or sucessfull message.
   */
  const paramsScan = {
    TableName: 'FailedEmailNotifications',
    ProjectionExpression:
      'SESDestinationAddress, FailedEmailMessageId, SnsPublishTime',
    FilterExpression: 'SESDestinationAddress = :SESDestinationAddress',
    ExpressionAttributeValues: {
      ':SESDestinationAddress': SESDestinationAddress,
    },
  };
  await ddb
    .scan(paramsScan)
    .promise()
    .then((data) => {
      data.Items.forEach((d) => {
        queriedEmail = d.SESDestinationAddress;
        queriedMessageId = d.FailedEmailMessageId;
        queriedSnsPublishTime = d.SnsPublishTime;
      });
    })
    .catch((err) => {
      console.log(
        `[INFO-LOG] - Receieve Email address  ${queriedEmail} never failed before. Continuing the process... ${err}`
      );
    });

  console.log('Email-Address : ', queriedEmail);
  console.log('Message-id : ', queriedMessageId);
  console.log('Published_time : ', queriedSnsPublishTime);

  let messageLogger =
    new Date().toLocaleString() + ',' + 'Success' + ',' + queriedEmail;

  /**
   * Checking if the MessageType received from the SNS is the "Delivery"
   * Insert if the email was never been pushed to the user mailbox, otherwise
   * update the retryCounter to 1.
   */
  if (SESMessageType == 'Bounce') {
    /*
        check if the user already present in the database.
    */
    if (queriedEmail && queriedMessageId) {
      const paramsUpdate = {
        TableName: 'FailedEmailNotifications',
        Key: {
          FailedEmailMessageId: queriedMessageId,
          SnsPublishTime: queriedSnsPublishTime,
        },
        UpdateExpression: 'ADD retryCount :incByOne',
        ExpressionAttributeValues: {
          ':incByOne': 1,
        },
      };

      /**
       * Previous entry has been found, hence updating the retryCounter by 1
       * Else insert the new entry to the database with retryCounter set to 0.
       */
      await ddb
        .update(paramsUpdate)
        .promise()
        .then((data) => {
          console.log(
            `[INFO-LOG] - User Email ${SESDestinationAddress} had already Bounced before, Hence updating the Retry Counter.`
          );
        })
        .catch((err) => {
          console.log(
            `[ERROR-LOG] - Something went wrong. Could not update the record for ${SESDestinationAddress}. -  ${err}`
          );
        });
    } else {
      /**
       * Inserting the new values to the database.
       */
      await ddb
        .put(paramsInsert)
        .promise()
        .then((data) => {
          console.log(
            `[INFO-LOG] - Inserting the Bounced message for user email ${SESDestinationAddress}.`
          );
        })
        .catch((err) => {
          console.log(
            `[ERROR-LOG] - Something went wrong. Could not insert the Bounced message entry to db for user ${SESDestinationAddress}. - ${err}`
          );
        });
    }
  } else if (SESMessageType == 'Delivery') {
    /**
     * we create a file for each successfull devlivery of the mails to the end-user
     */
    function uploadFileOnS3(fileData, fileName) {
      return new Promise((resolve, reject) => {
        (async () => {
          const params = {
            Bucket: 'message-tracker-bucket',
            Key: fileName,
            Body: fileData,
          };
          console.log(`file data :${fileData}`);
          console.log(`file name :${fileName}`);
          try {
            const response = await s3.upload(params).promise();
            console.log('Response: ', response);
            resolve(response);
          } catch (err) {
            reject(err);
          }
        })();
      });
    }

    (async () => {
      await this.uploadFileOnS3(
        messageLogger,
        'message-tracker-' + uuidv4() + '.csv'
      );
    })().catch((e) => console.log('Caught: ' + e));

    /*
        check if the user already present in the database.
    */
    if (queriedEmail && queriedMessageId) {
      const paramsUpdate = {
        TableName: 'FailedEmailNotifications',
        Key: {
          FailedEmailMessageId: queriedMessageId,
          SnsPublishTime: queriedSnsPublishTime,
        },
        UpdateExpression: 'ADD retryCount :incByOne',
        ExpressionAttributeValues: {
          ':incByOne': 1,
        },
      };

      /**
       * Previous entry has been found, hence updating the retryCounter by 1
       * Else insert the new entry to the database with retryCounter set to 0.
       */
      await ddb
        .update(paramsUpdate)
        .promise()
        .then((data) => {
          console.log(
            `[INFO-LOG] - User Email ${SESDestinationAddress} has already Delivered before, Hence updating the Retry Counter.`
          );
        })
        .catch((err) => {
          console.log(
            `[ERROR-LOG] - Something went wrong. Could not update the record for ${SESDestinationAddress}. -  ${err}`
          );
        });
    } else {
      /**
       * Inserting the new values to the database.
       */
      await ddb
        .put(paramsInsert)
        .promise()
        .then((data) => {
          console.log(
            `[INFO-LOG] - Inserting the successful delivery of message to user email ${SESDestinationAddress}.`
          );
        })
        .catch((err) => {
          console.log(
            `[ERROR-LOG] - Something went wrong. Could not insert the successful delivery entry to db for user ${SESDestinationAddress}. - ${err}`
          );
        });
    }
  }
};
