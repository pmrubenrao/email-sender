/**
 * v1.0: This lambda function would trigger through S3,
 * and saves the information from file it reads from s3
 * to the dynamoDB
 */

const aws = require('aws-sdk');

const s3 = new aws.S3({ apiVersion: '2006-03-01' });

aws.config.update({ region: 'us-east-1' });
const ddb = new aws.DynamoDB.DocumentClient();

exports.handler = async function (event, context) {
  /**
   * EXtracting the information from the S3 bucket
   */
  const bucket = event.Records[0].s3.bucket.name;
  console.log('raw-evet:: ', event);
  const key = decodeURIComponent(
    event.Records[0].s3.object.key.replace(/\+/g, ' ')
  );
  const params = {
    Bucket: bucket,
    Key: key,
  };
  try {
    const response = await s3.getObject(params).promise();
    console.log('From s3 bucket file :', response);
    const fileContent = JSON.parse(response.Body.toString('utf-8'));
    console.log('filecontent:: ', fileContent);

    const paramsInsert = {
      TableName: 'message-sync-table',
      Item: {
        SubscriptionEmail_c: fileContent.SubscriptionEmail_c,
        Echo_Ideac: fileContent.Echo_Ideac,
        Echo_IsActivec: fileContent.Echo_IsActivec,
        Echo_SubscriptionType_c: fileContent.Echo_SubscriptionType_c,
      },
    };

    console.log('SubscriptionEmail_c : ', fileContent.SubscriptionEmail_c);
    console.log('Echo_Ideac : ', fileContent.Echo_Ideac);
    console.log('Echo_IsActivec : ', fileContent.Echo_IsActivec);
    console.log(
      'Echo_SubscriptionType_c : ',
      fileContent.Echo_SubscriptionType_c
    );
    /**
     * Inserting the extracted value to dyanamoDB.
     */
    await ddb
      .put(paramsInsert)
      .promise()
      .then((data) => {
        console.log(
          `[INFO-LOG] - Synchronising the message with dynamodb for user email ${fileContent.SubscriptionEmail_c}.`
        );
      })
      .catch((err) => {
        console.log(
          `[ERROR-LOG] - Something went wrong. Could not synchronise db for user ${fileContent.SubscriptionEmail_c}. - ${err}`
        );
      });
  } catch (err) {
    console.log(err);
    const message = `Error getting object ${key} from bucket ${bucket}.`;
    console.log(message);
    throw new Error(message);
  }
};
