const AWS = require('aws-sdk');
const helper = require('./message-poller-helper.js');

const nodemailer = require('nodemailer');
const sesTransport = require('nodemailer-ses-transport');

const s3 = new AWS.S3({ apiVersion: '2006-03-01' });
const { v4: uuidv4 } = require('uuid');
let messageLogger = '';

class messagePoller {
  constructor(event, context, callback) {
    this.event = event;
    this.context = context;
    this.callback = callback;
  }

  startProcess() {
    return new Promise(async (resolve, reject) => {
      try {
        console.log('Event received : ', this.event);
        let emailIDs = [];
        this.event.Records.forEach((record) => {
          emailIDs.push(record.body);
        });

        for (const emailID of emailIDs) {
          await this.sendBulkEmail(emailID);
          // this.sendBulkMailSMTP(emailID);
        }

        (async () => {
          await this.uploadFileOnS3(
            messageLogger,
            'message-tracker-' + uuidv4() + '.csv'
          );
        })().catch((e) => console.log('Caught: ' + e));

        var responseObj = helper.responseObj('Email sent successfully', 200);
        responseObj.data = {};
        resolve(responseObj);
      } catch (error) {
        console.log('Error SendBulkEmail StartProcess', error);
        var errorObject = {};
        errorObject.statusCode = 500;
        errorObject.statusMessage = JSON.stringify(error);
        reject(errorObject);
      }
    });
  }

  uploadFileOnS3(fileData, fileName) {
    return new Promise((resolve, reject) => {
      (async () => {
        const params = {
          Bucket: 'message-tracker-bucket',
          Key: fileName,
          Body: fileData,
        };
        console.log(`file data :${fileData}`);
        console.log(`file name :${fileName}`);
        try {
          const response = await s3.upload(params).promise();
          console.log('Response: ', response);
          resolve(response);
        } catch (err) {
          reject(err);
        }
      })();
    });
  }

  sendBulkEmail(emailID) {
    return new Promise((resolve, reject) => {
      const mailOptions = {
        from: emailID,
        to: emailID,
        text: 'This is some text',
        html: '<b>This is some HTML</b>',
      };

      function callback(error, info) {
        if (error) {
          console.log(error);
          messageLogger =
            messageLogger +
            '\n' +
            new Date() +
            '\t' +
            JSON.stringify(info.response) +
            ',' +
            JSON.stringify(info.envelope.to[0]);
          reject(messageLogger);
        } else {
          console.log('Message sent: ' + JSON.stringify(info));
          messageLogger =
            messageLogger +
            '\n' +
            new Date().toLocaleString() +
            '\t' +
            JSON.stringify(info.response.split(' ', 2)) +
            ',' +
            JSON.stringify(info.envelope.to[0]);
          resolve(messageLogger);
        }
      }

      // Send e-mail using SMTP
      mailOptions.subject = 'Nodemailer SMTP transporter';
      const smtpTransporter = nodemailer.createTransport({
        port: 2587,
        host: 'email-smtp.us-east-1.amazonaws.com',
        secureConnection: false,
        auth: {
          user: 'AKIATTAOMKVP5V5NRE52',
          pass: 'BBbSkqeD9qM9xOy3RmdXGI7ll1RpCTxBvK8ELAsCtdhn',
        },
        tls: {
          ciphers: 'SSLv3',
        },
        debug: true,
      });
      smtpTransporter.sendMail(mailOptions, callback);
    });
  }
}

module.exports = messagePoller;
